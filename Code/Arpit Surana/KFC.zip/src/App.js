import AuthRoute from "./routes/AuthRoute";

function App() {
  return (
    <div>
      <AuthRoute />
    </div>
  );
}

export default App;
