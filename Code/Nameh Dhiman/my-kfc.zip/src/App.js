import Home from './pages/Home';
import Careers from './pages/Careers';
import About from './pages/About';

function App() {
  return (
    <div className="App">
      <Home/>
      {/* <Careers/> */}
      {/* <About/> */}
    </div>
  );
}

export default App;
